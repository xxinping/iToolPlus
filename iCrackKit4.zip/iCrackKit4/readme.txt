Cracking Apps with iCrackKit4 - By bl2c&p
------------------------------------------

iCrackKit does not require a jailbreak--it works by masquerading as iTunes.

iCrackKit makes use of the latest available advances in reverse-engineering Apple's protocols and standards.
- iOS 9 removes the ability to archive, and thus the ability to extract apps from the device.
- iOS 8.4.1 and below allow you to turn an app into a DRM-protected IPA.
- iCrackKit removes the DRM from these IPAs and repackages them with App2IPA, creating usable, installable IPA files.
- These files can then be installed on any iOS device.

Usage:
The programs are very simple.

IPAInstaller <ipa filename>, then plug in your device and watch.
CrackApp <bundleId> <output filename>, then plug in your device and watch.

If you enter the arguments wrong, the program will crash. Just run it again.

IMPORTANT:
Sometimes, when running CrackApp, you will get a COPY FAILED error.
Just wait a few seconds to a few minutes, run it again, and it will succeed.